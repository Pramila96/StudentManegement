package com.example.StudentManegement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManegementApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentManegementApplication.class, args);
	}

}
